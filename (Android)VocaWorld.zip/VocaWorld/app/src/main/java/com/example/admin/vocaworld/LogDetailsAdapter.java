package com.example.admin.vocaworld;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * Created by sowmya B V on 10/31/2018.
 */


public class LogDetailsAdapter extends BaseAdapter {

    private final List<ModelClass> logdetails;
    Context context;

    public LogDetailsAdapter(Context context, List<ModelClass> logdetails) {
        this.context = context;
        this.logdetails = logdetails;

    }

    @Override
    public int getCount() {
        return logdetails.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {
        return getCount();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    class ViewHolder {
        TextView tvDate, tvCount, tvUsage;
        LinearLayout llPlaceImage;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = convertView;
        final ViewHolder viewHolder;

        View currentFocus = ((Activity) context).getCurrentFocus();
        if (currentFocus != null) {
            currentFocus.clearFocus();
        }

        if (view == null) {
            viewHolder = new ViewHolder();
            view = LayoutInflater.from(context).inflate(R.layout.cust_log_details_layout, null);

        } else {
            viewHolder = (ViewHolder) view.getTag();
        }

        viewHolder.tvDate = (TextView) view.findViewById(R.id.tv_date_log_details);
        viewHolder.tvCount = (TextView) view.findViewById(R.id.tv_count_log_details);
        viewHolder.tvUsage = (TextView) view.findViewById(R.id.tv_usage_log_details);
//        Log.e("date",logdetails.get(position).getDate());
//        Log.e("count", String.valueOf(logdetails.get(position).getCount()));
//        Log.e("usage",String.valueOf(logdetails.get(position).getTotalTime()));

        viewHolder.tvDate.setText(logdetails.get(position).getDate());
        viewHolder.tvUsage.setText(String.valueOf(logdetails.get(position).getTotalTime())+" mins");
        viewHolder.tvCount.setText(String.valueOf(logdetails.get(position).getCount()));

        view.setTag(viewHolder);
        return view;
    }

}
