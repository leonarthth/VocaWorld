package com.example.admin.vocaworld;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import static android.content.Context.MODE_PRIVATE;
import static com.example.admin.vocaworld.SampleSharedPreferences.PREFS_APP_FILE;
import static com.example.admin.vocaworld.WelcomeFragment.totalTime;


/**
 * A simple {@link Fragment} subclass.
 */
public class DaysFragment extends Fragment implements View.OnClickListener {
    View view;
    TextView tvDay1, tvDay2, tvDay3, tvDay4, tvDay5, tvDay6;
    android.support.v4.app.FragmentManager fm;
    android.support.v4.app.FragmentTransaction ft;
    ImageView ivBack;
    private SharedPreferences sharedPreference;


    public DaysFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_days, container, false);

        sharedPreference = getActivity().getSharedPreferences(PREFS_APP_FILE, MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreference.edit();
        init();
        onClick();

        return view;
    }

    private void init() {

        tvDay1 = view.findViewById(R.id.tv_day1_day);
        tvDay2 = view.findViewById(R.id.tv_day2_day);
        tvDay3 = view.findViewById(R.id.tv_day3_day);
        tvDay4 = view.findViewById(R.id.tv_day4_day);
        tvDay5 = view.findViewById(R.id.tv_day5_day);
        tvDay6 = view.findViewById(R.id.tv_day6_day);
        ivBack = view.findViewById(R.id.iv_back_day);
    }


    private void onClick() {

        tvDay1.setOnClickListener(this);
        tvDay2.setOnClickListener(this);
        tvDay3.setOnClickListener(this);
        tvDay4.setOnClickListener(this);
        tvDay5.setOnClickListener(this);
        tvDay6.setOnClickListener(this);
        ivBack.setOnClickListener(this);
    }

    public void setFragment(android.support.v4.app.Fragment frag) {

//        hideKeyboardFragment(mActivity,frag.getView());
//        hideKeyboardActivity(mActivity);
        if (frag != null) {
            fm = this.getFragmentManager();

            try {
                fm.beginTransaction()
                        .replace(R.id.container_main, frag)
                        .setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .addToBackStack(frag.getClass().getName())
                        .commit();
            } catch(Exception e) {
                e.printStackTrace();
            }
        } else {
            // error in creating fragment
            Log.e("fragment", "Error in creating fragment");
        }
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_day1_day:
                Fragment day1 = new DayDetailFragment();
                Bundle bundle1 = new Bundle();
                bundle1.putString("day", tvDay1.getText().toString());
                day1.setArguments(bundle1);
                setFragment(day1);
                break;

            case R.id.tv_day2_day:
                Fragment day2 = new DayDetailFragment();
                Bundle bundle2 = new Bundle();
                bundle2.putString("day", tvDay2.getText().toString());
                day2.setArguments(bundle2);
                setFragment(day2);
                break;

            case R.id.tv_day3_day:
                Fragment day3 = new DayDetailFragment();
                Bundle bundle3 = new Bundle();
                bundle3.putString("day", tvDay3.getText().toString());
                day3.setArguments(bundle3);
                setFragment(day3);
                break;


            case R.id.tv_day4_day:
                Fragment day4 = new DayDetailFragment();
                Bundle bundle4 = new Bundle();
                bundle4.putString("day", tvDay4.getText().toString());
                day4.setArguments(bundle4);
                setFragment(day4);
                break;

            case R.id.tv_day5_day:
                Fragment day5 = new DayDetailFragment();
                Bundle bundle5 = new Bundle();
                bundle5.putString("day", tvDay5.getText().toString());
                day5.setArguments(bundle5);
                setFragment(day5);
                break;

            case R.id.tv_day6_day:
                Fragment day6 = new DayDetailFragment();
                Bundle bundle6 = new Bundle();
                bundle6.putString("day", tvDay6.getText().toString());
                day6.setArguments(bundle6);
                setFragment(day6);
                break;

            case R.id.iv_back_day:

//
                getFragmentManager().popBackStack();

                break;
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        SharedPreferences.Editor editor = sharedPreference.edit();
        editor.putLong("timeSpent", totalTime);
        Log.e("DayFragment", String.valueOf(totalTime));
        editor.apply();

    }
}
