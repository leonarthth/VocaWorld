package com.example.admin.vocaworld;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by sowmya B V on 10/31/2018.
 */

public class DetailsAdapter extends BaseAdapter {

    Context context;
    private ArrayList<String> vocabularyList;
    ArrayList<String> definationList;
    ArrayList<String> exampleSentencesList;
    ArrayList<String> partOfSpeechlist;
    ArrayList<String> exampleList;

    public DetailsAdapter(Context context, ArrayList<String> vocabularyList, ArrayList<String> definationList, ArrayList<String> exampleSentencesList, ArrayList<String> partOfSpeechlist, ArrayList<String> exampleList) {
        this.context = context;
        this.vocabularyList = vocabularyList;
        this.definationList = definationList;
        this.exampleSentencesList = exampleSentencesList;
        this.partOfSpeechlist = partOfSpeechlist;
        this.exampleList = exampleList;
    }

    @Override
    public int getCount() {
        return partOfSpeechlist.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    class ViewHolder{
       ImageView ivArrow;
       TextView tvWord, tvMeaning, tvAdj, tvExample, tvExampleSentence;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
       View view;

        final ViewHolder viewHolder;
        view = LayoutInflater.from(context).inflate(R.layout.cust_day_details_layout,null);
        viewHolder = new ViewHolder();
        viewHolder.tvWord = view.findViewById(R.id.tv_word);
        viewHolder.tvMeaning = view.findViewById(R.id.tv_meaning);
        viewHolder.tvAdj = view.findViewById(R.id.tv_adj);
        viewHolder.tvExample = view.findViewById(R.id.tv_example);
        viewHolder.ivArrow = view.findViewById(R.id.iv_arrow);
        viewHolder.tvExampleSentence = view.findViewById(R.id.tv_dialoug_text);

        viewHolder.tvWord.setText(vocabularyList.get(position));
        viewHolder.tvExample.setText(exampleList.get(position));
        viewHolder.tvAdj.setText(partOfSpeechlist.get(position));
        viewHolder.tvMeaning.setText(definationList.get(position));
        viewHolder.ivArrow.setImageResource(R.drawable.down);
        viewHolder.tvExampleSentence.setText(exampleSentencesList.get(position));

        viewHolder.ivArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewHolder.ivArrow.setImageResource(R.drawable.up);
                viewHolder.tvExampleSentence.setVisibility(View.VISIBLE);
            }
        });

        viewHolder.tvExampleSentence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewHolder.ivArrow.setImageResource(R.drawable.down);
                viewHolder.tvExampleSentence.setVisibility(View.GONE);
            }
        });
        view.setTag(viewHolder);
        return view;
    }
}
