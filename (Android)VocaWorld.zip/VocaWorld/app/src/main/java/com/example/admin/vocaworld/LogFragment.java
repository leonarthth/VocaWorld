package com.example.admin.vocaworld;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static com.example.admin.vocaworld.MainActivity.logDetails;
import static com.example.admin.vocaworld.MainActivity.timeElapsed;
import static com.example.admin.vocaworld.MainActivity.timeSpent;
import static com.example.admin.vocaworld.SampleSharedPreferences.PREFS_APP_FILE;


/**
 * A simple {@link Fragment} subclass.
 */
public class LogFragment extends Fragment {
    View view;
    android.support.v4.app.FragmentManager fm;
    android.support.v4.app.FragmentTransaction ft;
    ImageView ivBack;
    ListView listView;
    public static List<Long> timeSpentList = new ArrayList<>();
    LogDetailsAdapter adapter;
    SharedPreferences preferences;


    public LogFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_log, container, false);
        preferences = getActivity().getSharedPreferences(PREFS_APP_FILE, MODE_PRIVATE);

        ivBack = view.findViewById(R.id.iv_back_log);
        listView = view.findViewById(R.id.lv_log);

        if (logDetails.size()!=0) {

//
//            LinkedHashSet<ModelClass> linkedHashSet = new LinkedHashSet<>();
//            linkedHashSet.addAll(logDetails);
//            logDetails.clear();
//            logDetails.addAll(linkedHashSet);
//            if (isFirstTime)
//            {
//                Log.e("For First Time","-------------------------");
//                SharedPreferences.Editor editor = preferences.edit();
//                editor.putLong("timeSpent", timeSpent + timeElapsed);
//                Log.e("TotalTime", String.valueOf(timeSpent + timeElapsed));
//                editor.putString("currentDate", date);
//                Log.e("CurrentDate", String.valueOf(date));
//                editor.putInt("currentCount", MainActivity.count);
//                Log.e("CurrentCount", String.valueOf(MainActivity.count));
//                editor.putBoolean("isFirstTime",false);
//                editor.apply();
//
//            } else
//            {
//
//                if (formattedDate.equals(date))
//                {
//                    Log.e("Same Date","-------------------------");
//                    //    count += 1;
////                Log.e("CountList", String.valueOf(count));
//
//                }
//                else
//
//                {
//                    Log.e("End Of Day","-------------------------");
//                    ModelClass modelClass = new ModelClass();
//                    modelClass.setCount(MainActivity.count);
//                    modelClass.setDate(date);
//                    modelClass.setTotalTime(timeSpent);
//                    logDetails.add(modelClass);
//
//                    LinkedHashSet<ModelClass> linkedHashSet1 = new LinkedHashSet<>();
//                    linkedHashSet1.addAll(logDetails);
//                    logDetails.clear();
//                    logDetails.addAll(linkedHashSet1);
//
//                    saveModelListInLocal(logDetails, "logDetails");
//                    SharedPreferences.Editor editor = preferences.edit();
//                    editor.putLong("timeSpent", 0);
//                    editor.putString("currentDate", formattedDate);
//                    editor.putInt("currentCount", 0);
//                    editor.apply();
//                    timeSpent=0;
//                    MainActivity.count=0;
//                    date=formattedDate;
//                }
//            }

            adapter = new LogDetailsAdapter(getActivity(), logDetails);
            listView.setAdapter(adapter);
        }
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });


        timeSpentList = getListFromLocal("timeSpentList");
        return view;
    }
    public List<Long> getListFromLocal(String key)
    {
        SharedPreferences prefs = getActivity().getSharedPreferences("PREFS_APP_FILE", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<Long>>() {}.getType();
        return gson.fromJson(json, type);

    }

    public void setFragment(Fragment frag) {

//        hideKeyboardFragment(mActivity,frag.getView());
//        hideKeyboardActivity(mActivity);
        if (frag != null) {
            fm = this.getFragmentManager();

            try {
                fm.beginTransaction()
                        .replace(R.id.container_main, frag)
                        .setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .addToBackStack(frag.getClass().getName())
                        .commit();
            } catch(Exception e) {
                e.printStackTrace();
            }
        } else {
            // error in creating fragment
            Log.e("fragment", "Error in creating fragment");
        }
    }
    public void saveModelListInLocal(List<ModelClass> list, String key) {

        SharedPreferences prefs = getActivity().getSharedPreferences("PREFS_APP_FILE", getActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(key, json);
        editor.apply();     // This line is IMPORTANT !!!

    }
    public List<ModelClass> getModelListFromLocal(String key)
    {

        SharedPreferences prefs = getActivity().getSharedPreferences("PREFS_APP_FILE", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<ModelClass>>() {}.getType();
        return gson.fromJson(json, type);

    }
}
