package com.example.admin.vocaworld;


import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.LinkedHashSet;

import static android.content.Context.MODE_PRIVATE;
import static com.example.admin.vocaworld.MainActivity.hourglass;
import static com.example.admin.vocaworld.MainActivity.logDetails;
import static com.example.admin.vocaworld.MainActivity.timeSpent;
import static com.example.admin.vocaworld.SampleSharedPreferences.PREFS_APP_FILE;


/**
 * A simple {@link Fragment} subclass.
 */
public class WelcomeFragment extends Fragment {
    View view;
    android.support.v4.app.FragmentManager fm;
    android.support.v4.app.FragmentTransaction ft;
    TextView tvUserName, tvStart, tvSetNotification, tvTotalTime;
    String userName;
    private long milliLeft;
    private long min;
    private long sec;
    long totalSeconds = 30;
    long intervalSeconds = 1;
    public static long totalTime;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    public static String pickerTime, currentTime;
    public static Calendar mcurrentTime = null;
    public static int[] hour = {0};
    public static int[] minute = {0};
    long temp = 0;
    TextView tvHistory;


    public WelcomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_welcome, container, false);

        tvUserName = view.findViewById(R.id.tv_username_welcome);
        tvStart = view.findViewById(R.id.tv_start_welcome);
        tvSetNotification = view.findViewById(R.id.tv_set_notification_welcome);
        tvTotalTime = view.findViewById(R.id.tv_total_time);
        tvHistory = view.findViewById(R.id.tv_history_welcome);
        preferences = getActivity().getSharedPreferences(PREFS_APP_FILE, MODE_PRIVATE);
        editor=preferences.edit();


        userName = preferences.getString("userName", "");
        Log.e("userName",userName);
        tvUserName.setText(userName);

        totalTime=preferences.getLong("timeSpent",  0);

        String strTime= String.valueOf(totalTime);
        tvTotalTime.setText(strTime+" mins");





        tvStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timeSpent=preferences.getLong("timeSpent",  0);



//                //SharedPreferences.Editor editor = preferences.edit();
//                editor.putLong("timeSpent", preferences.getLong("timeSpent",  0));
//                Log.e("TotalTimeAtNavigate", String.valueOf(preferences.getLong("timeSpent",  0)));
//                editor.apply();
//                timeSpent=preferences.getLong("timespent",0);

                hourglass.startTimer();
                setFragment(new DaysFragment());
            }
        });

        tvHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setFragment(new LogFragment());
            }
        });
        tvSetNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // TODO Auto-generated method stub
                 hour = new int[1];
                 minute = new int[1];



                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {


                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        //eReminderTime.setText( selectedHour + ":" + selectedMinute);
                        pickerTime = selectedHour + ":" + selectedMinute;
//
                        hour[0] = selectedHour;
                        minute[0] = selectedMinute;
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.HOUR_OF_DAY, selectedHour);
                        calendar.set(Calendar.MINUTE, selectedMinute);

                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("ServieHour", String.valueOf(selectedHour));
                        editor.putString("ServiceMinute", String.valueOf(selectedMinute));
                        editor.apply();

                    }
                }, hour[0], minute[0], true);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();

            }
        });


        return view;
    }





    public void setFragment(android.support.v4.app.Fragment frag) {

        if (frag != null) {
            fm = this.getFragmentManager();

            try {
                fm.beginTransaction()
                        .replace(R.id.container_main, frag)
                        .setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .addToBackStack(frag.getClass().getName())
                        .commit();
            } catch(Exception e) {
                e.printStackTrace();
            }
        } else {
            // error in creating fragment
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if(hourglass.isRunning()){

            hourglass.stopTimer();
        }

    }
}
