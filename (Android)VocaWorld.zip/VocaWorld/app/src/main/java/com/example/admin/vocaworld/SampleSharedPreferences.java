package com.example.admin.vocaworld;

/**
 * Created by sowmya B V on 10/30/2018.
 */

public class SampleSharedPreferences {

    public static final String SHARED = "SAMPLE";
    public static final String PREFS_APP_FILE = "Voca_Preference_File";

    public static final String USER_ID = "user_id";
    public static final String PASSWORD = "password";
    public static final String IS_LOGGED_IN = "is_logged_in";


}
