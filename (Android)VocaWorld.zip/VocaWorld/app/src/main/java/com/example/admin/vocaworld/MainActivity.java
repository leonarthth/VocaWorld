package com.example.admin.vocaworld;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.FrameLayout;

import com.ankushgrover.hourglass.Hourglass;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import static com.example.admin.vocaworld.SampleSharedPreferences.PREFS_APP_FILE;


public class MainActivity extends AppCompatActivity {
    FrameLayout container;
    android.support.v4.app.FragmentManager fm;
    android.support.v4.app.FragmentTransaction ft;
    String userName;
    Boolean isLoggedIn;
    public static boolean isStart = false;
    boolean isFirstTime=true;
    public static String minutes;
    private SharedPreferences preferences;
    public static  Hourglass hourglass;
    ModelClass modelClass;

    public static long timeElapsed = 0;

    public  static long timeSpent=0;
    public static List<ModelClass> logDetails = new ArrayList<>();
    public String date;
    public int count = 0;
    private String formattedDate;
    private boolean firstTime=true;
    private String CurrentformattedDate;
    private String currentDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        preferences = getSharedPreferences(PREFS_APP_FILE, MODE_PRIVATE);
        isLoggedIn = preferences.getBoolean("isLoggedIn", false);
        isFirstTime = preferences.getBoolean("isFirstTime", true);
        if (isLoggedIn)
        {
            setFragmentWithoutBackstack(new WelcomeFragment());
        }
        else
        {
            setFragmentWithoutBackstack(new LoginFragment());
        }




        Date c1 = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        formattedDate = df.format(c1);
        Log.e("formattedDated",formattedDate);



            logDetails = getModelListFromLocal("logDetails");
            count = preferences.getInt("currentCount", 0);
            date = preferences.getString("currentDate", formattedDate);
            timeSpent = preferences.getLong("timeSpent", 0);
            //currentDate=preferences.getString("CurrentformattedDate",CurrentformattedDate);
            Log.e("TimeSpentOnCreate", String.valueOf(timeSpent));


        if(logDetails == null)
        {
            logDetails = new ArrayList<>();
        }




        Log.e("2222222222222", "222222222222");



            if (isFirstTime)
            {
                Log.e("For First Time","-------------------------");
                SharedPreferences.Editor editor = preferences.edit();
                editor.putLong("timeSpent", timeSpent + timeElapsed);
                Log.e("TotalTime", String.valueOf(timeSpent + timeElapsed));
                editor.putString("currentDate", date);
                Log.e("CurrentDate", String.valueOf(date));
                editor.putInt("currentCount", count);
                Log.e("CurrentCount", String.valueOf(count));
                editor.putBoolean("isFirstTime",false);
                editor.apply();

            } else
            {

                if (formattedDate.equals(date))
                {
                    Log.e("Same Date","-------------------------");
                //    count += 1;
//                Log.e("CountList", String.valueOf(count));

                }
                else

                {
//                    Log.e("End Of Day","-------------------------");
//                    ModelClass modelClass = new ModelClass();
//                    modelClass.setCount(count);
//                    modelClass.setDate(date);
//                    modelClass.setTotalTime(timeSpent);
//                    logDetails.add(modelClass);

//                    LinkedHashSet<ModelClass> linkedHashSet1 = new LinkedHashSet<>();
//                    linkedHashSet1.addAll(logDetails);
//                    logDetails.clear();
//                    logDetails.addAll(linkedHashSet1);

                    saveModelListInLocal(logDetails, "logDetails");
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putLong("timeSpent", 0);
                    editor.putString("currentDate", formattedDate);
                    editor.putInt("currentCount", 0);
                    editor.apply();
                    timeSpent=0;
                    count=0;
                    date=formattedDate;
                }
            }




        container = findViewById(R.id.container_main);


       hourglass = new Hourglass(86400000, 1000) {
            @Override
            public void onTimerTick(long timeRemaining) {
                // Update UI

               timeElapsed = 86400000 - timeRemaining;
                Log.e("Running Time", String.valueOf(timeElapsed));
                timeElapsed = timeElapsed/1000;
                timeElapsed = (int) timeElapsed/60;
                if (firstTime)
                {
                    if (timeElapsed==1)
                    {
                        if (formattedDate.equals(date))
                        {
                            count+=1;
                            firstTime=false;
                        }
                    }
                }

                       Log.e("CurrentMinutes", String.valueOf(timeElapsed));
                       SharedPreferences.Editor editor = preferences.edit();
                       editor.putLong("timeSpent", timeSpent + timeElapsed);
                       Log.e("TotalTime", String.valueOf(timeSpent + timeElapsed));
                       editor.apply();
                       Log.e("CountingList", String.valueOf(count));
                       Log.e("Hourglass", "Storage true----------------------------");

                Date c1 = Calendar.getInstance().getTime();
                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                CurrentformattedDate = df.format(c1);


                if (CurrentformattedDate.equals(date))
                {
                    Log.e("Same Date","-------------------------");

                    //    count += 1;
//                Log.e("CountList", String.valueOf(count));

                }
                else
                {
                    Log.e("End Of Day","-------------------------");
                    modelClass = new ModelClass();
                    modelClass.setCount(count);
                    modelClass.setDate(date);
                    modelClass.setTotalTime(timeSpent);
                    logDetails.add(modelClass);

//                    LinkedHashSet<ModelClass> linkedHashSet = new LinkedHashSet<>();
//                    linkedHashSet.addAll(logDetails);
//                    logDetails.clear();
//                    logDetails.addAll(linkedHashSet);

                    saveModelListInLocal(logDetails, "logDetails");
                    SharedPreferences.Editor editor1 = preferences.edit();
                    editor1.putLong("timeSpent", 0);
                    editor1.putString("currentDate", formattedDate);
                    editor1.putInt("currentCount", 0);
                    //editor1.putString("CurrentformattedDate",CurrentformattedDate);
                    editor1.apply();
                    timeSpent=0;
                    count=0;
                    date=CurrentformattedDate;

                }


            }


            @Override
            public void onTimerFinish() {
                // Timer finished



            }

        };



    }


    public void setFragmentWithoutBackstack(android.support.v4.app.Fragment frag) {

//        hideKeyboardFragment(mActivity,frag.getView());
//        hideKeyboardActivity(mActivity);
        if (frag != null) {
            fm = this.getSupportFragmentManager();

            try {
                fm.beginTransaction()
                        .replace(R.id.container_main, frag)
                        .setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit();
            } catch(Exception e) {
                e.printStackTrace();
            }
        } else {
            // error in creating fragment
            Log.e("fragment", "Error in creating fragment");
        }
    }




    @Override
    protected void onPause() {
        super.onPause();

        Log.e("onPauseStorage", "TRue-----------------");
            SharedPreferences.Editor editor = preferences.edit();
            editor.putLong("timeSpent", timeSpent + timeElapsed);
            Log.e("TotalTime", String.valueOf(timeSpent + timeElapsed));
            editor.putString("currentDate", formattedDate);
            Log.e("CurrentDate", String.valueOf(formattedDate));
            editor.putInt("currentCount", count);
            Log.e("CurrentCount", String.valueOf(count));
            editor.apply();
        if(hourglass.isRunning())
        {
            hourglass.pauseTimer();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();


        timeSpent = preferences.getLong("timeSpent", 0);
        firstTime=true;
        if (hourglass.isPaused()) {
            hourglass.stopTimer();
            hourglass.startTimer();

        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();


        SharedPreferences.Editor editor = preferences.edit();
        Log.e("TotalResult",timeSpent+"---"+timeElapsed);
        editor.putLong("timeSpent", timeSpent + timeElapsed);
        timeElapsed=0;

        Log.e("TotalTime", String.valueOf(timeSpent + timeElapsed));
        editor.putString("currentDate", formattedDate);
        Log.e("CurrentDate", String.valueOf(formattedDate));
        editor.putInt("currentCount", count);
        Log.e("CurrentCount", String.valueOf(count));
        editor.apply();
        Log.e("onDestroyStorage","TRue-----------------");

    }

    public void saveModelListInLocal(List<ModelClass> list, String key) {

        SharedPreferences prefs = getSharedPreferences("PREFS_APP_FILE", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(key, json);
        editor.apply();     // This line is IMPORTANT !!!

    }
    public List<ModelClass> getModelListFromLocal(String key)
    {

        SharedPreferences prefs = getSharedPreferences("PREFS_APP_FILE", Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<ModelClass>>() {}.getType();
        return gson.fromJson(json, type);

    }
}
