package com.example.admin.vocaworld;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class DayDetailFragment extends Fragment {
    View view;
    String day;
    TextView tvSelectDay;
    ArrayList<String> vocabularyList, definationList, exampleSentenceList,exampleList, partOfSpeechlist;
    ArrayList<String> tempVocabularyList, tempDefinationList, tempExampleSentenceList,tempExampleList, tempPartOfSpeechlist;
    ArrayList<Integer> arrowsList;
    DetailsAdapter adapter;
    ListView listView;
    ImageView ivBack;
    String[] vocabulary = {"generous", "optimistic", "kind", "shy", "eccentric", "rude", "sociable", "spoilt",
            "ambitious", "lazy", "moody", "selfish", "turn on", "look after", "fill in", "find out",
            "try on", "look up", "pick up", "take off", "turn off", "get on well", "casual", "easy-going",
            "bad-tempered", "kind", "big-headed", "smart", "cruel", "calm", "fussy", "modest",
            "make a mess", "make a speech", "make a phone call", "do someone a favor", "make up your mind", "the washing-up", "make a noise", "do my best",
            "absorb", "abundant", "accumulate", "adjacent", "assumptions", "ceased", "concerned", "concrete",
            "conform", "constant", "dense", "dominant", "eccentric", "emerge", "partial", "periodic",
            "primary", "profound", "promote", "reliable", "rely", "subsequent", "sufficient", "varied",
            "egoist", "introvert", "extrovert", "ambivert", "misanthrope", "misogynist", "misogamist", "ascetic",
            "disparage", "equivocate", "titillate", "adulate", "proscribe", "obviate", "militate", "malign", "dichotomy","epitomize",
            "philander", "philtre","bibliophile","Anglophile","asocial", "tome", "philological", "sociological"};

    String[] definaton = {"willing to give money, help, kindness, etc., especially more than is usual or expected",
            "hoping or believing that good things will happen in the future",
            "generous, helpful, and thinking about other people's feelings",
            "nervous and uncomfortable with other people",
            "strange or unusual, sometimes in a humorous way",
            "not polite; offensive or embarrassing",
            "Sociable people like to meet and spend time with other people",
            "a spoiled person, especially a child, is rude and behaves badly because they have always been given what they want and allowed to do what they want",
            "having a strong wish to be successful, powerful, or rich",
            "not willing to work or use any effort",
            "If someone is moody, their moods change suddenly and they become angry or unhappy easily",
            "Someone who is selfish only thinks of their own advantage",
            "When you turn on a piece of equipment or a supply of something, you cause heat, sound, or water to be produced by adjusting the controls",
            "If you look after someone or something, you do what is necessary to keep them healthy, safe, or in good condition",
            "If you fill in a form or other document requesting information, you write information in the spaces on it",
            "If you find something out, you learn something that you did not already know, especially by making a deliberate effort to do so",
            "If you try on a piece of clothing, you put it on to see if it fits you or if it looks nice",
            "If you look up a fact or a piece of information, you find it out by looking in something such as a reference book or a list",
            "When you pick something up, you lift it up",
            "If you take a garment off, you remove it",
            "When you turn off a piece of equipment or a supply of something, you stop heat, sound, or water being produced by adjusting the controls",
            "If you get on well with someone, you like them and have a friendly relationship with them",
            "Casual clothes are not formal or not suitable for special occasions",
            "relaxed and not easily upset or worried",
            "A bad-tempered person becomes angry and annoyed easily",
            "Someone who is kind behaves in a gentle, caring, and helpful way towards other people",
            "thinking that you are more important or more intelligent than you really are",
            "having a clean, tidy, and stylish appearance",
            "extremely unkind and unpleasant and causing pain to people or animals intentionally",
            "peaceful, quiet, and without worry",
            "not easily satisfied, or having very high standards about particular things:",
            "not usually talking about or making obvious your own abilities and achievements",
            "to do something badly or spoil something",
            "a formal talk given usually to a large number of people on a special occasion",
            "If you make a phone call, you dial someone's phone number and speak to them by phone",
            "If you do someone a favour, you do something for them even though you do not have to",
            "to decide",
            "the act of cleaning plates, pans, glasses, knives, forks, etc. after a meal, or the objects needing to be washed",
            "speak or act in a way designed to attract a lot of attention or publicity",
            "do all one can",
            "to take in or draw up",
            "possessing a lot of something, often more than what is needed",
            "to gather or collect",
            "located next to something; beside",
            "opinions which are taken for granted or presumed to be true",
            "ended, stopped, or discontinued",
            "worried or upset",
            "referring to an actual, material thing",
            "to act according to set standards",
            "staying the same, or not getting less or more",
            "having parts that are close together so that it is difficult to go or see through",
            "Being the most important force or component; commanding or controlling",
            "unusual; different from the normal standard",
            "to come into view, often from a hidden place",
            "not complete",
            "occurring at regular time intervals",
            "the most important; the first in a series",
            "going beyond what is on the surface; deep",
            "to help or encourage",
            "trustworthy and dependable",
            "to depend on or put trust in",
            "occurring after something else",
            "enough for what is needed, but not going beyond that",
            "characterized by many different qualities",
            "a person who believes in self-advancement",
            "someone who is shy, quiet, and prefers to spend time alone rather than often being with other people",
            "an energetic happy person who enjoys being with other people",
            "a person whose personality has features typical of both introverts and extroverts",
            "someone who dislikes and avoids other people",
            "a man who hates women or believes that men are much better than women",
            "a person who hates marriage",
            "avoiding physical pleasures and living a simple life, often for religious reasons",
            "to criticize someone or something in a way that shows you do not respect or value him, her, or it",
            "to speak in a way that is intentionally not clear and confusing to other people, especially to hide the truth",
            "to make someone excited intentionally but only a little; stimulate pleasurably",
            "to admire or praise someone very much, especially when this is more than is deserved; flatter lavishly",
            "(of a government or other authority) to not allow something",
            "to remove a difficulty, especially so that action to deal with it becomes unnecessary",
            "to make something less likely to happen or succeed",
            "causing or intending to cause harm or evil",
            "a difference between two completely opposite ideas or things",
            "to be a perfect example of a quality or type of thing",
            "readily or frequently enter into casual sexual relationships with women",
            "a drink supposed to arouse love and desire for a particular person in the drinker; a love potion",
            "a person who loves or collects books",
            "a person who is not English but is interested in, likes, or supports England or the UK",
            "avoiding social interaction; inconsiderate of or hostile to others",
            "a book, especially a large, heavy, scholarly one",
            "relating to the study of language, especially its history and development",
            "related to or involving sociology"};

    String[] partOfSpeech = {"adjective","adjective","adjective","adjective","adjective","adjective","adjective","adjective",
                             "adjective","adjective","adjective","adjective","phrasal verb","phrasal verb","phrasal verb","phrasal verb",
                             "phrasal verb","phrasal verb","phrasal verb","phrasal verb","phrasal verb","phrasal verb","adjective","adjective",
                             "adjective","adjective","adjective","adjective","adjective","adjective","adjective","adjective",
                             "expression","expression","expression","expression","expression","expression","expression","expression",
                             "verb","adjective","verb","adjective","noun","verb","adjective","adjective",
                             "verb","adjective","adjective","adjective","adjective","verb","adjective","adjective",
                             "adjective","adjective","verb","adjective","verb","adjective","adjective","adjective",
                             "noun","noun","noun","noun","noun","noun","noun","adjective",
                             "verb","verb","verb","verb","verb","verb","verb","adjective","noun", "verb", "verb",
            "noun", "noun","noun","adjective", "noun", "adjective","adjective"};

    String[] exampleSentence = {"He always gives fantastic presents.", "She always looks on the bright side of things.",
            "She cares about people and wants to make them happy.", "He hates meeting people and having to talk to them.",
            "She has some very strange ideas.", "He always says things to upset and annoy people.",
            "She likes being with people and is good fun.", "She always has to get everything she wants.",
            "She wants to do really well in life.", "He never does any work at all.",
            "You never know how he's going to be, happy or sad.", "He only ever thinks of himself.",
            "There's a programme I want to watch. Can you turn on the TV?", "I can't go out tonight. I'm looking after the children.",
            "Just fill it in and give it to the receptionist.", "Can you find out the time of the next train to London?",
            "Can I try on these jeans, please?", "If there's a word I don't know, I look it up in my dictionary.",
            "Oh, dear- I've dropped my purse. Could you pick it up for me? Thanks.", "Please take off your dirty shoes before you come in",
            "No one's watching the TV. Turn it off!",
            "I get on well with my sister, but not my brother. We fight all the time.", "His casual behaviour was wholly inappropriate for such a formal occasion.",
            "an easy-going attitude/manner", "She's very bad-tempered in the mornings!",
            "She is warmhearted and kind to everyone and everything.", "I'm trying not to get too big-headed",
            "Guy looks very smart in his new suit, doesn't he?", "Don't tease him about his weight - it's cruel.",
            "He has a very calm manner.", "He's so fussy about the house - everything has to be absolutely perfect.",
            "He's very modest about his achievements", "I made a real mess of my final exams.",
            "I had to make a speech at my brother's wedding", "Wait there for a minute. I have to make a phone call.",
            "I've come to ask you to do me a favour.", "First she said yes, then she said no, but in the end she made up her mind to marry him.",
            "We have an agreement in our house. I cook dinner every evening and afterwards James does the washing-up.", "Ssh! You mustn't make a noise. The baby's asleep.",
            "My teacher says I must work harder, but I can't work any harder, I'm doing my best", "We are using a sponge to absorb most of the liquid that was spilled.",
            "The food was abundant at Thanksgiving dinner; we spent the next two weeks eating leftovers.", "The geologist was hoping to accumulate more rock specimens on his trip out West.",
            "Our house is adjacent to the corner grocery store.", "I made some assumptions about Dana's character without really knowing her.",
            "When I lost my job, my expensive nights on the town ceased.", "I was concerned when you did not show up for work at the usual time.",
            "Detectives look for concrete evidence, such as hairs and fingerprints, when solving a crime.", "Teenagers often feel the pressure to conform in order to be popular.",
            "Traffic jams are a constant source of irritation in modern life.", "The crowds at the game were so dense we could barely move.",
            "For hundreds of years, the Romans were the dominant force in the Mediterranean.", "My aunt is quite an eccentric lady, with her bright hats adorned with birds and eggs.",
            "It is always exciting to watch a plane emerge from the clouds and head towards the landing strip", "We have only a partial understanding of our galaxy.",
            "At periodic times through the day, you need to take this medication.", "The primary source of crime in major cities is drug use.",
            "Aristotle gave us a profound understanding of human life.", "The treaty was designed to promote trade relations between the two nations.",
            "The Toyota is one of the most reliable cars on the market-it rarely breaks down.",
            "You can rely on me to pay you back in two weeks' time.",  "The defeat of Greece and its subsequent decline led to the birth of the Roman Empire.",
            "Fortunately, we found sufficient food for the last remaining days of our camping trip.", "People in my school come from varied backgrounds-one student grew up in Kansas, another in Saudi Arabia.",
            "their boss is a demanding egoist who insists that everything be done her way.", "His research further shows that about 70% of top executives are introverts.",
            "Most sales people are extroverts.", "Ambiverts like to be with people, but they also like to be by themselves.",
            "The young people thought him a gloomy misanthrope, because he never joined in their sports.", "Many have spoken out to say the worst trolling comes not from misogynist men, but from fellow feminists.",
            "Your confirmed bachelor friend — who swears he'll never get married — might just like his independence, or he might be a misogamist.", "They live a very ascetic life.",
            "The actor's work for charity has recently been disparaged in the press as an attempt to get publicity.", "She accused the minister of equivocating, claiming that he had deliberately avoided telling the public how bad the problem really was.",
            "So many adverts these days are designed to titillate.", "He was adulated in the press.",
            "The Athletics Federation has banned the runner from future races for using proscribed drugs.", "A peaceful solution would obviate the need to send a UN military force.",
            "he complexity and costliness of the judicial system militate against justice for the individual.", "Foreign domination had a malign influence on local politics.",
            "There is often a dichotomy between what politicians say and what they do.",
            "With little equipment and unsuitable footwear, she epitomizes the inexperienced and unprepared mountain walker.",
            "they accepted that their husbands would philander with other women.",
            "his philtres and potions.",
            "Being a bibliophile of non-fiction books has also led me to a worrying conclusion.",
            "the Anglophile General Marshall",
            "a tendency to asocial behaviour",
            "a weighty tome",
            "The book was the outcome of his philological work.",
            "sociological theory/research"};

    public DayDetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_day_details, container, false);

        tvSelectDay = view.findViewById(R.id.tv_title_day_details);
        listView = view.findViewById(R.id.lv_details);
        ivBack = view.findViewById(R.id.iv_back_day_details);

        vocabularyList = new ArrayList<>();
        definationList = new ArrayList<>();
        exampleSentenceList = new ArrayList<>();
        partOfSpeechlist = new ArrayList<>();
        arrowsList = new ArrayList<>();
        exampleList = new ArrayList<>();
        tempVocabularyList = new ArrayList<>();
        tempDefinationList = new ArrayList<>();
        tempExampleSentenceList = new ArrayList<>();
        tempPartOfSpeechlist = new ArrayList<>();
        tempExampleList = new ArrayList<>();


        for (int i = 0; i < vocabulary.length; i++) {

            vocabularyList.add(vocabulary[i]);

        }

        for (int i = 0; i < definaton.length; i++) {

            definationList.add(definaton[i]);

        }

        for (int i = 0; i < partOfSpeech.length; i++) {

            partOfSpeechlist.add(partOfSpeech[i]);

        }

        for (int i = 0; i < exampleSentence.length; i++) {

            exampleSentenceList.add(exampleSentence[i]);

        }

        for (int i = 0; i < 90; i++) {

            exampleList.add("example");

        }





        Bundle bundle = this.getArguments();
        if (bundle != null) {
            day = bundle.getString("day");
            Log.e("day",day);
            tvSelectDay.setText(day);
            tempVocabularyList.clear();
            tempDefinationList.clear();
            tempExampleSentenceList.clear();
            tempPartOfSpeechlist.clear();
            tempExampleList.clear();
            if(tvSelectDay.getText().toString().equals("DAY 1")){
                for(int j=0; j<15; j++){
                    tempVocabularyList.add(vocabulary[j]);
                    tempDefinationList.add(definaton[j]);
                    tempExampleSentenceList.add(exampleSentence[j]);
                    tempPartOfSpeechlist.add(partOfSpeech[j]);
                    tempExampleList.add("example");
                }
                adapter = new DetailsAdapter(getActivity(),tempVocabularyList,tempDefinationList,tempExampleSentenceList,tempPartOfSpeechlist,tempExampleList);
                listView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }else if(tvSelectDay.getText().toString().equals("DAY 2")){
                for(int j=15; j<30; j++){
                    tempVocabularyList.add(vocabulary[j]);
                    tempDefinationList.add(definaton[j]);
                    tempExampleSentenceList.add(exampleSentence[j]);
                    tempPartOfSpeechlist.add(partOfSpeech[j]);
                    tempExampleList.add("example");
                }
                adapter = new DetailsAdapter(getActivity(),tempVocabularyList,tempDefinationList,tempExampleSentenceList,tempPartOfSpeechlist,tempExampleList);
                listView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }else if(tvSelectDay.getText().toString().equals("DAY 3")){
                for(int j=30; j<45; j++){
                    tempVocabularyList.add(vocabulary[j]);
                    tempDefinationList.add(definaton[j]);
                    tempExampleSentenceList.add(exampleSentence[j]);
                    tempPartOfSpeechlist.add(partOfSpeech[j]);
                    tempExampleList.add("example");
                }
                adapter = new DetailsAdapter(getActivity(),tempVocabularyList,tempDefinationList,tempExampleSentenceList,tempPartOfSpeechlist,tempExampleList);
                listView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }else if(tvSelectDay.getText().toString().equals("DAY 4")){
                for(int j=45; j<60; j++){
                    tempVocabularyList.add(vocabulary[j]);
                    tempDefinationList.add(definaton[j]);
                    tempExampleSentenceList.add(exampleSentence[j]);
                    tempPartOfSpeechlist.add(partOfSpeech[j]);
                    tempExampleList.add("example");
                }
                adapter = new DetailsAdapter(getActivity(),tempVocabularyList,tempDefinationList,tempExampleSentenceList,tempPartOfSpeechlist,tempExampleList);
                listView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }else if(tvSelectDay.getText().toString().equals("DAY 5")){
                for(int j=60; j<75; j++){
                    tempVocabularyList.add(vocabulary[j]);
                    tempDefinationList.add(definaton[j]);
                    tempExampleSentenceList.add(exampleSentence[j]);
                    tempPartOfSpeechlist.add(partOfSpeech[j]);
                    tempExampleList.add("example");
                }
                adapter = new DetailsAdapter(getActivity(),tempVocabularyList,tempDefinationList,tempExampleSentenceList,tempPartOfSpeechlist,tempExampleList);
                listView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }else if(tvSelectDay.getText().toString().equals("DAY 6")){
                for(int j=75; j<90; j++){
                    tempVocabularyList.add(vocabulary[j]);
                    tempDefinationList.add(definaton[j]);
                    tempExampleSentenceList.add(exampleSentence[j]);
                    tempPartOfSpeechlist.add(partOfSpeech[j]);
                    tempExampleList.add("example");
                }
                adapter = new DetailsAdapter(getActivity(),tempVocabularyList,tempDefinationList,tempExampleSentenceList,tempPartOfSpeechlist,tempExampleList);
                listView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
        }

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });
        return view;
    }

}
