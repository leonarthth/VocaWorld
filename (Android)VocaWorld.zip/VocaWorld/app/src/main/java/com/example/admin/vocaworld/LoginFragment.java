package com.example.admin.vocaworld;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import static android.content.Context.MODE_PRIVATE;
import static com.example.admin.vocaworld.SampleSharedPreferences.PREFS_APP_FILE;


/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFragment extends Fragment {
    View view;
    EditText etUserName;
    TextView tvRegister;
    FrameLayout container;
    android.support.v4.app.FragmentManager fm;
    android.support.v4.app.FragmentTransaction ft;


    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_login, container, false);

        etUserName = view.findViewById(R.id.edt_user_name_login);
        tvRegister = view.findViewById(R.id.tv_register_login);

        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setFragment(new WelcomeFragment());
//                Fragment fragment = new WelcomeFragment();
//                Bundle bundle = new Bundle();
//                bundle.putString("userName", etUserName.getText().toString());
//                fragment.setArguments(bundle);
//                setFragment(fragment);

                Log.e("userNameLogin",etUserName.getText().toString());

                SharedPreferences.Editor editor = getActivity().getSharedPreferences(PREFS_APP_FILE,MODE_PRIVATE).edit();
                editor.putString("userName", etUserName.getText().toString());
                editor.putBoolean("isLoggedIn",true);
                editor.commit();
            }
        });


        return view;
    }

    public void setFragment(android.support.v4.app.Fragment frag) {

//        hideKeyboardFragment(mActivity,frag.getView());
//        hideKeyboardActivity(mActivity);
        if (frag != null) {
            fm = this.getFragmentManager();

            try {
                fm.beginTransaction()
                        .replace(R.id.container_main, frag)
                        .setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .commit();
            } catch(Exception e) {
                e.printStackTrace();
            }
        } else {
            // error in creating fragment
            Log.e("fragment", "Error in creating fragment");
        }
    }
}
