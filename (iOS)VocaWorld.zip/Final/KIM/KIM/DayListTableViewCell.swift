//
//  DayListTableViewCell.swift
//  KIM
//
//  Created by Admin on 10/29/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class DayListTableViewCell: UITableViewCell {

    @IBOutlet var moreButton : UIButton!
    @IBOutlet var upImageView : UIImageView!
    @IBOutlet var moreView : UIView!
    @IBOutlet var moreLabel: UILabel!
    
    @IBOutlet var wordLabel: UILabel!
    @IBOutlet var posLabel: UILabel!
    @IBOutlet var definitionLabel: UILabel!
    @IBOutlet var exampleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
