//
//  RegisterViewController.swift
//  KJM
//
//  Created by Admin on 10/27/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet var name : UITextField!
    @IBOutlet var registerButton : UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        registerButton.layer.cornerRadius = 12
        self.navigationController?.navigationBar.isHidden = true
    }
    
     @IBAction func registerButtonAction(_ sender : UIButton) {
        if name.text == "" {
            Alert.showAlertWith(message: "Please enter username", viewController: self)
        } else {
            let newDate = Date()
            let dateFormatter3 = DateFormatter()
            dateFormatter3.dateFormat = "dd-MM-yyyy"
            let todayDate = dateFormatter3.string(from: newDate)
            Defaults.setValueForLogin(name: name.text!)
            Defaults.setdate(date: todayDate)
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "WelcomeViewController") as! WelcomeViewController
            self.navigationController?.pushViewController(nextViewController, animated: true)
        }
    }
}

