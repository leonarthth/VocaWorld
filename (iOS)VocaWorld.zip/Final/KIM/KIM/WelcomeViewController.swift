//
//  WelcomeViewController.swift
//  KJM
//
//  Created by Admin on 10/27/18.
//  Copyright © 2018 Admin. All rights reserved.
//

//import Foundation
import UIKit

class WelcomeViewController: UIViewController {
    
    @IBOutlet var name : UILabel!
    @IBOutlet var startButton : UIButton!
    @IBOutlet var timeMins : UILabel!
    
    @IBOutlet var historyButton : UIButton!
    @IBOutlet var hoursLabel : UILabel!
    @IBOutlet var minsLabel : UILabel!
    let appdelegate = AppDelegate()
    let database = MyDatabase()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        name.text = "Hello, " + Defaults.getValueForLogin()
        startButton.layer.cornerRadius = 12
        historyButton.layer.cornerRadius = 12
        
        //        Setting user login count
        let newDate = Date()
        let dateFormatter3 = DateFormatter()
        dateFormatter3.dateFormat = "dd-MM-yyyy"
        let todayDate = dateFormatter3.string(from: newDate)
        if todayDate == Defaults.getdate() {
            //            if Defaults.getTime() > 1 {
            //                let temp = Defaults.getCount()
            //                Defaults.setCount(count: temp + 1)
            //            }
            timeMins.text = " \(Defaults.getTime()) mins"
            print(Defaults.getTime())
        } else {
            //            Defaults.setdate(date: todayDate)
            //            Defaults.setCount(count: 1)
        }
        print("User login count : \(Defaults.getCount())")
        print("User used Time : \(Defaults.getTime())")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
        appdelegate.stopTimer()
        let newDate = Date()
        let dateFormatter3 = DateFormatter()
        dateFormatter3.dateFormat = "dd-MM-yyyy"
        let todayDate = dateFormatter3.string(from: newDate)
        if todayDate == Defaults.getdate() {
            timeMins.text = " \(Defaults.getTime()) mins"
            print(Defaults.getTime())
        } else {
        }
        print("User login count : \(Defaults.getCount())")
        print("User used Time : \(Defaults.getTime())")
        
    }
    
    @IBAction func historyButtonAction(_ sender : UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "HistoryViewController") as! HistoryViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }

    @IBAction func startButtonAction(_ sender : UIButton) {
        appdelegate.startTimer()
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SelectDayViewController") as! SelectDayViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
}


