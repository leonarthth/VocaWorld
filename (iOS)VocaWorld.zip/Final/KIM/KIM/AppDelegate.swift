//
//  AppDelegate.swift
//  KIM
//
//  Created by Admin on 10/29/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,UINavigationControllerDelegate {

    var window: UIWindow?
    
    var timer: Timer?
    var totalTime = Int()
    var countAfterMin = 1
     var tempTime = Int()
    
    let database = MyDatabase()
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        // SQLite
        database.createOpenDB()

//        Defaults.setdate(date: "16-11-2018")
        let newDate = Date()
        let dateFormatter3 = DateFormatter()
        dateFormatter3.dateFormat = "dd-MM-yyyy"
        let todayDate = dateFormatter3.string(from: newDate)
        if todayDate == Defaults.getdate() {
            tempTime = Defaults.getTime()
            print("tempTime : \(tempTime)")
            totalTime = 0
            print(totalTime)
        } else {
            print("\(Defaults.getdate()) ok")
            if Defaults.getdate() != "" {
                self.database.OpenDB()
                self.database.insertKimData(date: Defaults.getdate() as NSString, visit: "\(Defaults.getCount())" as NSString, usage: "\(Defaults.getTime()) mins" as NSString)
                Defaults.setdate(date: todayDate)
                Defaults.setTime(time: 0)
                Defaults.setCount(count: 0)
                totalTime = 0
                tempTime = 0
            } else if Defaults.getdate() == "" {
                Defaults.setdate(date: todayDate)
                Defaults.setTime(time: 0)
                Defaults.setCount(count: 0)
                totalTime = 0
                tempTime = 0
            }
        }
//        startTimer()
       
        // Override point for customization after application launch.
        let name = Defaults.getValueForLogin()
        if name == "" {
            self.window = UIWindow(frame: UIScreen.main.bounds)
            let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let navigationController:UINavigationController = storyboard.instantiateInitialViewController() as! UINavigationController
            let rootViewController:UIViewController = storyboard.instantiateViewController(withIdentifier: "RegisterViewController") as UIViewController
            navigationController.viewControllers = [rootViewController]
            self.window?.rootViewController = navigationController
            self.window?.makeKeyAndVisible()
        } else {
            self.window = UIWindow(frame: UIScreen.main.bounds)
            let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let navigationController:UINavigationController = storyboard.instantiateInitialViewController() as! UINavigationController
            let rootViewController:UIViewController = storyboard.instantiateViewController(withIdentifier: "WelcomeViewController") as UIViewController
            navigationController.viewControllers = [rootViewController]
            self.window?.rootViewController = navigationController
            self.window?.makeKeyAndVisible()
        }
        
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        stopTimer()
//        if let timer = self.timer {
            self.timer?.invalidate()
            self.timer = nil
//        }
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


    
    func startTimer() {
//        self.totalTime = 60
        self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer() {
        print(self.totalTime)
        print(self.timeFormatted(self.totalTime) ) // will show timer
        if totalTime >= 0 {
            totalTime += 1
            let newDate = Date()
            let dateFormatter3 = DateFormatter()
            dateFormatter3.dateFormat = "dd-MM-yyyy"
            let todayDate = dateFormatter3.string(from: newDate)
            if todayDate == Defaults.getdate() {
                Defaults.setTime(time: (tempTime + self.timeFormatted(self.totalTime)) )
                print("\(Defaults.getTime()) mins")
                if self.timeFormatted(self.totalTime) == 1 {
                    if countAfterMin == 1 {
                        countAfterMin = 0
                        let tempCount = Defaults.getCount()
                        Defaults.setCount(count: tempCount + 1)
                    }
                }
                
            } else {
                print("\(Defaults.getdate()) ok")
                if Defaults.getdate() != "" {
                    self.database.OpenDB()
                    self.database.insertKimData(date: Defaults.getdate() as NSString, visit: "\(Defaults.getCount())" as NSString, usage: "\(Defaults.getTime()) mins" as NSString)
                    Defaults.setdate(date: todayDate)
                    Defaults.setTime(time: 0)
                    Defaults.setCount(count: 0)
                    totalTime = 0
                    tempTime = 0
                    stopTimer()
                    startTimer()
                } else if Defaults.getdate() == "" {
                    Defaults.setdate(date: todayDate)
                    Defaults.setTime(time: 0)
                    Defaults.setCount(count: 0)
                    totalTime = 0
                    tempTime = 0
                    stopTimer()
                    startTimer()
                }
            }
        } else {
            if let timer = self.timer {
                timer.invalidate()
                self.timer = nil
            }
        }
    }
    func timeFormatted(_ totalSeconds: Int) -> Int {
//                let seconds: Int = totalSeconds % 60
        let minutes: Int = (totalSeconds / 60) % 60
        return minutes //String(format: "%02d", minutes)
    }
    
    func stopTimer() {
        if let timer = self.timer {
            timer.invalidate()
            self.timer = nil
        }
        tempTime = Defaults.getTime()
        totalTime = 0
        countAfterMin = 1
    }
}

