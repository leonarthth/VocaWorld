//
//  Common.swift
//  KJM
//
//  Created by Admin on 10/27/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import Foundation
import UIKit

class Defaults {
 
    static func setValueForLogin(name : String) {
        UserDefaults.standard.setValue(name, forKey: "LoggedIn")
    }
    static func getValueForLogin() -> String {
        let name = UserDefaults.standard.string(forKey: "LoggedIn")
        return name ?? ""
    }
    
    static func setCount(count : Int) {
        UserDefaults.standard.setValue(count, forKey: "count")
    }
    static func getCount() -> Int {
        let count = UserDefaults.standard.value(forKey: "count")
        return count as! Int
    }
    
    static func setdate(date : String) {
        UserDefaults.standard.setValue(date, forKey: "date")
    }
    static func getdate() -> String {
        let date = UserDefaults.standard.string(forKey: "date")
        return date ?? ""
    }
    
    static func setTime(time : Int) {
        UserDefaults.standard.setValue(time, forKey: "time")
    }
    static func getTime() -> Int {
        let time = UserDefaults.standard.value(forKey: "time")
        return time as! Int
    }
    
    static func setDay(day : String) {
        UserDefaults.standard.setValue(day, forKey: "Day")
    }
    static func getDay() -> String {
        let day = UserDefaults.standard.string(forKey: "Day")
        return day ?? ""
    }
}

class Alert {
    static func showAlertWith(message : String, viewController : UIViewController) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
            print(action)
        }))
        viewController.present(alert, animated: true, completion: nil)
    }
}
