//
//  SQLiteManager.swift
//  MedicaTrix
//
//  Created by Admin on 7/26/18.
//  Copyright © 2018 Flappjacks. All rights reserved.
//

import Foundation
import SQLite3

class MyDatabase {
    
    var db: OpaquePointer? = nil
    var statement: OpaquePointer? = nil
    var syncstatus = NSString()
    
    func createOpenDB() {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("test.sqlite")
        do {
            try (fileURL as NSURL).setResourceValue(
                URLFileProtection.complete,
                forKey: .fileProtectionKey)
            print("protected")
        }
        catch {
            // Handle errors.
        }
        // open database
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("error opening database")
        } else {
            print("Opened database")
        }
        // create table
        if sqlite3_exec(db, "create table if not exists KimData (id integer primary key autoincrement, date text, visit text, usage text)", nil, nil, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error creating table: \(errmsg)")
        } else {
            print("KimData table created")
        }
        
    }
    
    func OpenDB() {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("test.sqlite")
        print(fileURL)
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("error opening database")
        } else {
            print("Opened database")
        }
    }
    
    func insertKimData(date : NSString, visit : NSString, usage: NSString) {
        
        if sqlite3_prepare_v2(db, "insert into KimData(date,visit,usage) values (?,?,?)", -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
        }
        
        if sqlite3_bind_text(statement, 1, date.utf8String, -1, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure binding medicineName: \(errmsg)")
            return
        }
        if sqlite3_bind_text(statement, 2, visit.utf8String, -1, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure binding medicineTakingTime: \(errmsg)")
            return
        }
        if sqlite3_bind_text(statement, 3, usage.utf8String, -1, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure binding medicineTakingType: \(errmsg)")
            return
        }
        
        
        if sqlite3_step(statement) != SQLITE_DONE {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("failure inserting data: \(errmsg)")
            return
        } else {
            print("KimData Record inserted successfully")
        }
        
        if sqlite3_finalize(statement) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error finalizing prepared statement: \(errmsg)")
        }
        
    }
    
    func readKimData() -> NSMutableArray {
        let readingValues = NSMutableArray()
        var date = String()
        var visit = String()
        var usage = String()
        
        if sqlite3_prepare(db, "SELECT * FROM KimData", -1, &statement, nil) != SQLITE_OK{
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing insert: \(errmsg)")
            return []
        }
        
        while(sqlite3_step(statement) == SQLITE_ROW){
            let id = sqlite3_column_int(statement, 0)
            
            if let cString = sqlite3_column_text(statement, 1) {
                date = String(cString: cString)
                print("date = \(date)")
            }
            
            if let cString = sqlite3_column_text(statement, 2) {
                visit = String(cString: cString)
                print("visit = \(visit)")
            }
            
            if let cString = sqlite3_column_text(statement, 3) {
                usage = String(cString: cString)
                print("usage = \(usage)")
            }
            
            
            let object =  MedicineModel().addDetailsWith(
                id: Int(id),
                date: date,
                visit: visit,
                usage: usage)
            readingValues.add(object)
        }
        return readingValues
    }
}
