//
//  MedicinesModel.swift
//  MedicaTrix
//
//  Created by Admin on 8/31/18.
//  Copyright © 2018 Flappjacks. All rights reserved.
//

import Foundation

class MedicineModel: NSObject {
    var id : Int!
    var date : String!
    var visit : String!
    var usage : String!

    func addDetailsWith(id : Int, date : String, visit : String, usage : String) -> MedicineModel {
        self.id = id
        self.date = date
        self.visit = visit
        self.usage = usage
        return self
    }
}
