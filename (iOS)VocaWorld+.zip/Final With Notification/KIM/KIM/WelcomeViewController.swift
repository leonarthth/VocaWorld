//
//  WelcomeViewController.swift
//  KJM
//
//  Created by Admin on 10/27/18.
//  Copyright © 2018 Admin. All rights reserved.
//

//import Foundation
import UIKit
import EventKit
import UserNotifications
import UserNotificationsUI

class WelcomeViewController: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource {
    
    @IBOutlet var name : UILabel!
    @IBOutlet var startButton : UIButton!
    @IBOutlet var timeMins : UILabel!
    
    @IBOutlet var historyButton : UIButton!
    @IBOutlet var settingNotificationButton : UIButton!
    @IBOutlet var pickView : UIView!
    @IBOutlet var timePickerView : UIPickerView!
    @IBOutlet var hoursLabel : UILabel!
    @IBOutlet var minsLabel : UILabel!
    @IBOutlet var doneButton : UIButton!
    
    var pickHours = ["00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23"]
    var pickMins = ["00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59"]
    var selectHour = "00"
    var selectMin = "00"
    let appdelegate = AppDelegate()
    let database = MyDatabase()
    
    override func viewDidLoad() {
        super.viewDidLoad()
         // Do any additional setup after loading the view, typically from a nib.
//        mail()
//        sendEmail(subject: "subject", body: "hello raja")
        name.text = "Hello, " + Defaults.getValueForLogin()
        startButton.layer.cornerRadius = 12
        settingNotificationButton.layer.cornerRadius = 12
        historyButton.layer.cornerRadius = 12
       
//        Setting user login count
        let newDate = Date()
        let dateFormatter3 = DateFormatter()
        dateFormatter3.dateFormat = "dd-MM-yyyy"
        let todayDate = dateFormatter3.string(from: newDate)
        if todayDate == Defaults.getdate() {
//            if Defaults.getTime() > 1 {
//                let temp = Defaults.getCount()
//                Defaults.setCount(count: temp + 1)
//            }
            timeMins.text = " \(Defaults.getTime()) mins"
            print(Defaults.getTime())
        } else {
//            Defaults.setdate(date: todayDate)
//            Defaults.setCount(count: 1)
        }
        print("User login count : \(Defaults.getCount())")
        print("User used Time : \(Defaults.getTime())")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
        appdelegate.stopTimer()
        let newDate = Date()
        let dateFormatter3 = DateFormatter()
        dateFormatter3.dateFormat = "dd-MM-yyyy"
        let todayDate = dateFormatter3.string(from: newDate)
        if todayDate == Defaults.getdate() {
            timeMins.text = " \(Defaults.getTime()) mins"
            print(Defaults.getTime())
        } else {
        }
        print("User login count : \(Defaults.getCount())")
        print("User used Time : \(Defaults.getTime())")
       
    }
    
    @IBAction func historyButtonAction(_ sender : UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "HistoryViewController") as! HistoryViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }

    @IBAction func startButtonAction(_ sender : UIButton) {
        appdelegate.startTimer()
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SelectDayViewController") as! SelectDayViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    @IBAction func settingNotificationButtonAction(_ sender : UIButton) {
        pickView.isHidden = false
        timePickerView.isHidden = false
        hoursLabel.isHidden = false
        minsLabel.isHidden = false
        doneButton.isHidden = false
    }
    
    @IBAction func doneButtonAction(_ sender : UIButton) {
        pickView.isHidden = true
        timePickerView.isHidden = true
        hoursLabel.isHidden = true
        minsLabel.isHidden = true
        doneButton.isHidden = true
        let selectHourInt = Int(selectHour)
        let selectMinInt = Int(selectMin)
        print(selectHourInt!)
        print(selectMinInt!)
        setNotification(hours: selectHourInt!, mins: selectMinInt!, text: "It’s time to study English. Let’s go. ")
    }
    
    func setNotification(hours: Int, mins: Int, text: String) {
        print("start")
        var date = DateComponents()
        date.hour = hours
        date.minute = mins
        let trigger = UNCalendarNotificationTrigger(dateMatching: date, repeats: true)
        
        let content = UNMutableNotificationContent()
        content.title = "Voca World"
        content.body = text
        content.categoryIdentifier = "alarm"
        content.sound = UNNotificationSound.default
        content.badge = 1
        //        let trigger1 = UNTimeIntervalNotificationTrigger.init(timeInterval: 5.0, repeats: false)
        //        let trigger1 = UNTimeIntervalNotificationTrigger(timeInterval: timeAmount, repeats: false)
        let request = UNNotificationRequest(identifier: text, content: content, trigger: trigger)
        //        center.add(request)
        
        
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().add(request){(error) in
            
            if (error != nil){
                
                print(error?.localizedDescription as Any)
            }
        }
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 2
    }
    // data method to return the number of row shown in the picker.
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        var row = pickerView.selectedRow(inComponent: 0)
        if component == 0 {
            return pickHours.count
        } else if component == 1 {
            return pickMins.count
        }
        return 1
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    // delegate method to return the value shown in the picker
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            selectHour = pickHours[row]
        } else if component == 1 {
            selectMin = pickMins[row]
        }
        //            print("\(selectHour) hours \(selectMin) mins")
        //            HeightTextField.text = defaults.string(forKey: "ProfileHeight")
        if component == 0 {
            return pickHours[row]
        } else if component == 1 {
            return pickMins[row]
        }
        return ""
    }
    
    // delegate method called when the row was selected.
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0{
            selectHour = pickHours[row]
        } else if component == 1 {
            selectMin = pickMins[row]
        }
        print("\(selectHour) hours \(selectMin) mins")
    }
}

extension WelcomeViewController : UNUserNotificationCenterDelegate {
    
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        print("Tapped in notification")
    }
    
    //This is key callback to present notification while the app is in foreground
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        print("Notification being triggered")
        //You can either present alert ,sound or increase badge while the app is in foreground too with ios 10
        //to distinguish between notifications
        //        if notification.request.identifier == "requestAlarm" {
        //
        //            completionHandler( [.alert,.sound,.badge])
        //
        //        }
    }
}
