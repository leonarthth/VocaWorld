//
//  SelectDayViewController.swift
//  KIM
//
//  Created by Admin on 10/29/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import Foundation
import UIKit

class SelectDayViewController: UIViewController {
    
    @IBOutlet var day1Button : UIButton!
    @IBOutlet var day2Button : UIButton!
    @IBOutlet var day3Button : UIButton!
    @IBOutlet var day4Button : UIButton!
    @IBOutlet var day5Button : UIButton!
    @IBOutlet var day6Button : UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.title = "Select DAY"
        day1Button.layer.cornerRadius = 12
        day2Button.layer.cornerRadius = 12
        day3Button.layer.cornerRadius = 12
        day4Button.layer.cornerRadius = 12
        day5Button.layer.cornerRadius = 12
        day6Button.layer.cornerRadius = 12
        
    }
    
    @IBAction func day1ButtonAction(_ sender : UIButton) {
        Defaults.setDay(day: "day1")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DayListViewController") as! DayListViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    @IBAction func day2ButtonAction(_ sender : UIButton) {
        Defaults.setDay(day: "day2")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DayListViewController") as! DayListViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    @IBAction func day3ButtonAction(_ sender : UIButton) {
        Defaults.setDay(day: "day3")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DayListViewController") as! DayListViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    @IBAction func day4ButtonAction(_ sender : UIButton) {
        Defaults.setDay(day: "day4")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DayListViewController") as! DayListViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    @IBAction func day5ButtonAction(_ sender : UIButton) {
        Defaults.setDay(day: "day5")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DayListViewController") as! DayListViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    @IBAction func day6ButtonAction(_ sender : UIButton) {
        Defaults.setDay(day: "day6")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DayListViewController") as! DayListViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
}
